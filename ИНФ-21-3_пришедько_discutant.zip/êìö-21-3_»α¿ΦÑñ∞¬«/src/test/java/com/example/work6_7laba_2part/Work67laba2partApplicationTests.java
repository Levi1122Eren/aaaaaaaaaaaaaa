package com.example.work6_7laba_2part;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Work67laba2partApplicationTests {

	@Test
	void contextLoads() {
	}

}
