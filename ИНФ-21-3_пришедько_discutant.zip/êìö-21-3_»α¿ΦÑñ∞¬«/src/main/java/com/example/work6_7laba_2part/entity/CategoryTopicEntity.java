package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "category_topic")
public class CategoryTopicEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_category_topic", nullable = false)
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "ID_category")
    private CategoryEntity category;

    @ManyToOne
    @JoinColumn(name = "ID_topic")
    private TopicEntity topic;
}