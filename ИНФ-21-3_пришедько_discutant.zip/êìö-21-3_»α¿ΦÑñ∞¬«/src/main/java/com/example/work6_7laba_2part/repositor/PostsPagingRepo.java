package com.example.work6_7laba_2part.repositor;

import com.example.work6_7laba_2part.entity.PostsEntity;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface PostsPagingRepo extends PagingAndSortingRepository<PostsEntity, Long> {
    @Override
    Page<PostsEntity> findAll(Pageable pageable);
    @Query("Select p from PostsEntity p left join CategoryEntity c on p.category = c.id_category")
    Page<PostsEntity> findAllWithCategory(Pageable pageable);
}
