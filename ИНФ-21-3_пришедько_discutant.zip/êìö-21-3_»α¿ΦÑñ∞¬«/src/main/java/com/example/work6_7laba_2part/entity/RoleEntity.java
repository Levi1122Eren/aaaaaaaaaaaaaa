package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;
import java.util.Objects;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "role")
public class RoleEntity implements GrantedAuthority {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "idrole")
    private Long idrole;

    @Column(name = "name_role")
    private String nameRole;

    @OneToMany(mappedBy = "roleByRole")
    private Collection<ClientloginEntity> clientloginsByIdrole;
    //private List<ClientloginEntity> clientloginEntityList;

    public RoleEntity(Long idrole, String nameRole) {
        this.idrole = idrole;
        this.nameRole = nameRole;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        RoleEntity that = (RoleEntity) o;
        return idrole == that.idrole && Objects.equals(nameRole, that.nameRole);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idrole, nameRole);
    }

    //public List<ClientloginEntity> getClientloginEntityList() {
    //  return clientloginEntityList;    }

    //public void setClientloginEntityList(List<ClientloginEntity> clientloginEntityList) {
     //   this.clientloginEntityList = clientloginEntityList;    }
    public Collection<ClientloginEntity> getClientloginsByIdrole() {
      return clientloginsByIdrole;    }

    public void setClientloginsByIdrole(Collection<ClientloginEntity>                                               clientloginsByIdrole) {
        this.clientloginsByIdrole = clientloginsByIdrole;    }

    @Override
    public String getAuthority() {
        return getNameRole();
    }
}
