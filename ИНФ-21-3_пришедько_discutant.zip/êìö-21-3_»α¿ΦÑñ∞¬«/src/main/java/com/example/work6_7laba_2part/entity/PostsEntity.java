package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "posts")
public class PostsEntity {
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "idpost")
    private Long idpost;
    @Basic
    @Column(name = "name_post")
    private String namePost;

    @Basic
    @Column(name = "category")
    private Long category;

    @Basic
    @Column(name = "del")
    private Boolean del = false;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "category",nullable = true, insertable = false, updatable = false)
    private CategoryEntity categoryEntity;

    @ManyToMany(fetch = FetchType.EAGER,
            cascade = {CascadeType.PERSIST})
    @JoinTable(name = "posts_tags", joinColumns = { @JoinColumn(name = "id_post")}, inverseJoinColumns = {@JoinColumn(name = "id_tag")})
    private List<TopicEntity> tags;


    @Size(max = 255)
    @NotNull
    @Column(name = "link_video", nullable = false)
    private String linkVideo;

    public void setDel(Boolean del)
    {
        this.del = del;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        PostsEntity that = (PostsEntity) o;
        return idpost == that.idpost && Objects.equals(namePost, that.namePost);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idpost, namePost);
    }

}
