package com.example.work6_7laba_2part.repositor;

public interface AudienceRepo {
}
