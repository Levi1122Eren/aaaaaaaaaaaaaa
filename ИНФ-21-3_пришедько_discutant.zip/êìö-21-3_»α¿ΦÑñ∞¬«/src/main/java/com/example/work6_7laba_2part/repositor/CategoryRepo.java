package com.example.work6_7laba_2part.repositor;

import com.example.work6_7laba_2part.entity.CategoryEntity;
import org.springframework.data.repository.CrudRepository;

public interface CategoryRepo extends CrudRepository<CategoryEntity, Long> {
}
