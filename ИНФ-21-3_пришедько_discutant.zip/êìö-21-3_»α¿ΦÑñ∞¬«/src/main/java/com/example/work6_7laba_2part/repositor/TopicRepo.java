package com.example.work6_7laba_2part.repositor;

import com.example.work6_7laba_2part.entity.TopicEntity;
import org.springframework.data.repository.CrudRepository;

public interface TopicRepo extends CrudRepository<TopicEntity, Long> {


}
