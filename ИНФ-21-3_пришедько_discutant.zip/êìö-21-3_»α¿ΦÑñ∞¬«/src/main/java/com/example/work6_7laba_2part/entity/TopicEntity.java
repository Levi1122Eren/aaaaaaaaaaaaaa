package com.example.work6_7laba_2part.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

@Entity
@Table(name = "Topic")
public class TopicEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_topic", nullable = false)
    private Integer id_topic;

    @Column(name = "Name")
    private String name;

    @Column(name = "Picture")
    private String picture;

    @ManyToMany(fetch = FetchType.EAGER,
            cascade = {
                    CascadeType.PERSIST,
                    CascadeType.MERGE
            },
            mappedBy = "tags")
    private Set<CategoryEntity> categoryes = new HashSet<>();

    @ManyToMany(fetch = FetchType.EAGER, cascade = {CascadeType.PERSIST, CascadeType.MERGE}, mappedBy = "tags")
    @JsonIgnore
    private List<PostsEntity> posts;

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        TopicEntity topic = (TopicEntity) o;
        return Objects.equals(id_topic, topic.id_topic) && Objects.equals(name, topic.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id_topic, name);
    }

    @Override
    public String toString() {
        return "TopicEntity{" +
                "id_topic=" + id_topic +
                ", name='" + name + '\'' +
                ", picture='" + picture + '\'' +
                '}';
    }
}