package com.example.work6_7laba_2part.repositor;

import com.example.work6_7laba_2part.entity.TeamsEntity;
import org.springframework.data.repository.CrudRepository;

public interface TeamsEntityRepo extends CrudRepository<TeamsEntity, Long> {
}
