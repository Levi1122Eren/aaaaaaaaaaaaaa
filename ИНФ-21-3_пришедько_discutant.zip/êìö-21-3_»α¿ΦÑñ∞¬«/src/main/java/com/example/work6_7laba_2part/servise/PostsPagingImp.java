package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.entity.PostsEntity;
import com.example.work6_7laba_2part.repositor.PostsEntityRepo;
import com.example.work6_7laba_2part.repositor.PostsPagingRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

@Service("postsPagingImp")
public class PostsPagingImp {
    private final PostsPagingRepo postsPagingRepo;

    @Autowired
    public PostsPagingImp(PostsPagingRepo postsEntityRepo) {this.postsPagingRepo = postsEntityRepo;};

    public Page<PostsEntity> allPosts(Pageable pageable){
        return postsPagingRepo.findAll(pageable);
    }

    public Page<PostsEntity> allPostsWithCategory(Pageable pageable) {
        return postsPagingRepo.findAllWithCategory(pageable);
    }

}
