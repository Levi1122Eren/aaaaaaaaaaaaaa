package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.attoparser.dom.Text;

import java.sql.Timestamp;

@Getter
@Setter
@Entity
@Table(name = "negative_actions")
public class NegActionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_action", nullable = false)
    private Integer id;

    @Column(name = "Reason")
    private Text reason;

    @Column(name = "Screenshots")
    private Text proofsPaths;

    @Column(name = "Date_and_time")
    private Timestamp date;

    @Column(name = "Kind")
    private int idKind;

    @Column(name = "ID_negative_user")
    private int idUser;

}