package com.example.work6_7laba_2part;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Work67laba2partApplication
{
	public static void main(String[] args)
	{
		SpringApplication.run(Work67laba2partApplication.class, args);
	}
}
