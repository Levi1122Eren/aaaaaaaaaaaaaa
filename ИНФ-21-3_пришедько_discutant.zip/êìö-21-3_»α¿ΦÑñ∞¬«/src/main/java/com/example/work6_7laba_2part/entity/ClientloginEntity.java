package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.attoparser.dom.Text;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "clientlogin")

public class ClientloginEntity implements UserDetails {
    public void setDeleted(Boolean deleted)
    {
        this.deleted = deleted;
    }

    public ClientloginEntity(String password, String email, String login)
    {
        this.password = password;
        this.email = email;
        this.login = login;
        this.deleted = false;
    }

    public Long getIdclient()
    {
        return idclient;
    }

    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Id
    @Column(name = "idclient")
    private Long idclient;

    @Column(name = "password")
    private String password;

    @Column(name = "lastname")
    private String lastname;

    @Column(name = "name")
    private String name;

    @Column(name = "surname")
    private String surname;

    @Column(name = "sex")
    private int sex;

    @Column(name = "country")
    private String country;

    @Column(name = "city")
    private String city;

    @DateTimeFormat(pattern="yyyy-MM-dd")
    @Column(name = "birthday")
    private Date birthday;

    @Column(name = "info")
    private Text info;

    @Column(name = "email")
    private String email;

    @Column(name = "nickname")
    private String nickname;

    @Column(name = "photo")
    private String photo;

    @Column(name = "login")
    private String login;

    @Column(name = "roleC")
    private Integer roleC;

    @Column(name = "deleted")
    private Boolean deleted;

    @ManyToOne
    @JoinColumn(name = "roleC", referencedColumnName = "idrole", insertable = false, updatable = false)
    private RoleEntity roleByRole;


    public String getLogin() {
        return login;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities()
    {
           List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
           authorities.add(new SimpleGrantedAuthority(roleByRole.getNameRole()));
           return authorities;
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return login;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ClientloginEntity that = (ClientloginEntity) o;
        return idclient == that.idclient && Objects.equals(password, that.password)
                && Objects.equals(lastname, that.lastname)
                && Objects.equals(login, that.login)
                && Objects.equals(roleC, that.roleC)
                && Objects.equals(deleted, that.deleted);
    }

    @Override
    public int hashCode() {
        return Objects.hash(idclient, password, lastname, login, roleC, deleted);
    }

}
