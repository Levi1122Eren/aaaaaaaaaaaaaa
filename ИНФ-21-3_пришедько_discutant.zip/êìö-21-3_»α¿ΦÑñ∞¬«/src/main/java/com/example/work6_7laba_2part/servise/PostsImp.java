package com.example.work6_7laba_2part.servise;

import com.example.work6_7laba_2part.entity.PostsEntity;
import com.example.work6_7laba_2part.repositor.PostsEntityRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("postsImp")
public class PostsImp {
    private final PostsEntityRepo postsEntityRepo;
    @Autowired
    public PostsImp(PostsEntityRepo postsEntityRepo) {
        this.postsEntityRepo = postsEntityRepo;
    }

    public Iterable<PostsEntity> allPosts(){
            return postsEntityRepo.findAll();
    }


    public Boolean savePost (PostsEntity postsEntity) {
        postsEntity.setDel(false);
        postsEntityRepo.save(postsEntity);
      return true;
    }


    /*public void updatePost(PostsEntity postsEntity) {
        postsEntity.setNamePost(postsEntity.getNamePost());
        postsEntity.setLinkVideo(postsEntity.getLinkVideo());
        postsEntityRepo.save(postsEntity);

    }*/

}
