package com.example.work6_7laba_2part.controllers;
import com.example.work6_7laba_2part.entity.ClientloginEntity;
import com.example.work6_7laba_2part.servise.SecurityClientLoginImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@Controller
public class ControllerAdmin
{
    private final SecurityClientLoginImp securityClientLoginImp;
    @Autowired
    public ControllerAdmin(SecurityClientLoginImp securityClientLoginImp)
    {
        this.securityClientLoginImp = securityClientLoginImp;
    }

    @GetMapping("/auth/admin")
    public String getRegistrPage(Model model)
    {
        model.addAttribute("allUsers", securityClientLoginImp.allUsers());
        return "admin2";
    }
    @GetMapping("/auth/{idclient}")
    public String deleteUser(@PathVariable("idclient") Long idclient, Model model)
    {
        ClientloginEntity clientloginEntity = securityClientLoginImp.findById(idclient);
        securityClientLoginImp.deleteUser(clientloginEntity);
        return "redirect:/admin2";
    }

    @GetMapping("/auth/admin/{idclient}")
    public String  gtIdUSer(@PathVariable("idclient") Long idclient, Model model)
    {
        model.addAttribute("allUsers", securityClientLoginImp.findById(idclient));
        return "admin2";
    }
}
