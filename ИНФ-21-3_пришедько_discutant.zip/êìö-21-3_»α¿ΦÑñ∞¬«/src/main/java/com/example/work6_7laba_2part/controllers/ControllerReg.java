package com.example.work6_7laba_2part.controllers;

import com.example.work6_7laba_2part.entity.*;
import com.example.work6_7laba_2part.repositor.CategoryRepo;
import com.example.work6_7laba_2part.repositor.PostsEntityRepo;
import com.example.work6_7laba_2part.repositor.PostsPagingRepo;
import com.example.work6_7laba_2part.repositor.TopicRepo;
import com.example.work6_7laba_2part.servise.PostsImp;
import com.example.work6_7laba_2part.servise.SecurityClientLoginImp;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.lang.reflect.Array;
import java.util.*;

@Controller
public class ControllerReg
{
    @Autowired
    private SecurityClientLoginImp securityClientLoginImp;
    @Autowired
    private PostsImp postsImp;
    @Autowired
    private PostsEntityRepo postsEntityRepo;

    @Autowired
    private PostsPagingRepo postsPagingRepo;

    @Autowired
    private CategoryRepo categoryRepo;

    @Autowired
    private TopicRepo topicRepo;


    @GetMapping("/auth/register")
    public String getRegistrPage(Model model)
    {
        model.addAttribute("userForm", new ClientloginEntity());
        return "register";
    }
    @GetMapping("/about-us")
    public String getAboutUs(Model model)
    {
        model.addAttribute("title", "О нас");
        return "about-us";
    }

    @GetMapping("/settings/filters")
    public String getSettings(Model model)
    {
        Iterable<CategoryEntity> categoryes = categoryRepo.findAll();
        Iterable<TopicEntity> tags = topicRepo.findAll();
        model.addAttribute("categoryes", categoryes);
        model.addAttribute("tags", tags);
        return "settings_topic-category";
    }

    @PostMapping("/settings/filters/topic/create")
    public String addTopic(@Valid TopicEntity topicEntity)
    {

        System.out.println(topicEntity);
        topicRepo.save(topicEntity);
        return "redirect:/settings/filters";
    }

    @PostMapping("/settings/filters/topic/update/{idTopic}")
    public String updateTopic(@PathVariable(value = "idTopic") Long idTopic, @Valid TopicEntity topicEntity)
    {

        topicRepo.findById(idTopic)
                .orElseThrow();

        TopicEntity topicResp =topicRepo.save(topicEntity);
        return "redirect:/settings/filters";
    }

    @PostMapping("/settings/filters/topic/delete/{idTopic}")
    public String deleteTopic(@PathVariable(value = "idTopic") Long idTopic)
    {
        TopicEntity topic = topicRepo.findById(idTopic)
                .orElseThrow();

        topicRepo.delete(topic);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return "redirect:/settings/filters";
    }

    @PostMapping("/settings/filters/category/create")
    public String addCategoty(@Valid CategoryEntity categoryEntity, Model model)
    {
        categoryRepo.save(categoryEntity);
        return "redirect:/settings/filters";
    }

    @PostMapping("/settings/filters/category/update/{idCategory}")
    public String updateCategory(@PathVariable(value = "idCategory") Long idCategory, @Valid CategoryEntity categoryEntity, Model model)
    {
        categoryRepo.findById(idCategory)
                .orElseThrow();

        CategoryEntity categoryResp =categoryRepo.save(categoryEntity);
        return "redirect:/settings/filters";
    }

    @PostMapping("/settings/filters/category/delete/{idCategory}")
    public String deleteCategory(@PathVariable(value = "idCategory") Long idCategory, Model model)
    {
        CategoryEntity category = categoryRepo.findById(idCategory)
                .orElseThrow();

        categoryRepo.delete(category);
        Map<String, Boolean> response = new HashMap<>();
        response.put("deleted", Boolean.TRUE);
        return "redirect:/settings/filters";
    }

    @PostMapping("/settings/filters/cat_topic/update/{idCategory}")
    public String updateCategoryTopic(@PathVariable(value = "idCategory") Long idCategory,
                                      @Valid CategoryEntity categoryEntity,
                                      @RequestParam(required = false,value = "id_topic[]") String[] id_topic, Model model)
    {

        CategoryEntity category = categoryRepo.findById(idCategory)
                .orElseThrow();

        if(id_topic != null && id_topic.length >0) {
            Set<TopicEntity> topicEntities = new HashSet<>();
            for (String id : id_topic) {
                TopicEntity newTopic = topicRepo.findById(Long.parseLong(id,10)).orElseThrow();
                topicEntities.add(newTopic);
                System.out.println(newTopic);
            }
            category.setTags(topicEntities);
        }
        CategoryEntity categoryResp =categoryRepo.save(category);
        return "redirect:/settings/filters";
    }

    @GetMapping("/main")
    public String getMainPage(@RequestParam(required = false, defaultValue = "") String filter,
                              Model model,
                              @PageableDefault (sort = {"idpost"},direction = Sort.Direction.DESC, size = 9) Pageable pageable)
    {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        ClientloginEntity user = (ClientloginEntity) authentication.getPrincipal();

        Page<PostsEntity> posts;
        if (user != null)
        {
            model.addAttribute("idclient", user.getIdclient());
        }
        else
        {
            model.addAttribute("idclient", 0L);
        }


        posts = postsPagingRepo.findAll(pageable);

        //вытягивание всех постов
        //Iterable<PostsEntity> posts= postsEntityRepo.findAll();
        model.addAttribute("posts",posts);
        return "main";
    }

    @GetMapping("/main/add-video")
    public String getAdd(Model model){
        model.addAttribute("postEntity",new PostsEntity());
        model.addAttribute("addV", "Добавить видео");
        return "add-video";
    }
    @PostMapping("/main/add-video")
    public String postAdd(@Valid PostsEntity postsEntity ){
        PostsEntity postsEntity1 = postsEntityRepo.save(postsEntity);
        //model.addAttribute("addV", "Добавить видео");
        return "redirect:/main/edit-post/"+postsEntity1.getIdpost();
    }

    @GetMapping("/main/edit-post/{idpost}")
    public String getEditPost(@PathVariable(value = "idpost") Long idpost,Model model){
        model.addAttribute("addU", "Upddate video");
        if(!postsEntityRepo.existsById(idpost)){
            return "redirect:/main";
        }
        PostsEntity postsEntity = postsEntityRepo.findById(idpost).orElse(new PostsEntity());
        Set<TopicEntity> topicEntities = null;
        Iterable<CategoryEntity> categoryes = categoryRepo.findAll();
        //postsEntityOptional.ifPresent(res::add);
        if(postsEntity.getCategory() != null){
            CategoryEntity category = categoryRepo.findById(postsEntity.getCategory()).orElseThrow();
            topicEntities = category.getTags();
            model.addAttribute("tagsForCat", topicEntities);
        }
        model.addAttribute("postsEntity",postsEntity);
        model.addAttribute("categoryes",categoryes);
      /*  model.addAttribute("post",new PostsEntity());*/
        return "edit-post";
    }

    @PostMapping("/main/edit-post/{idpost}")
    public String postEditPost(@PathVariable("idpost") Long idpost,
                               @RequestParam String namePost,
                               @RequestParam(value = "category") Long category,
                               @RequestParam(value = "linkVideo") String linkVideo,
                               @RequestParam(required = false,value = "id_tags[]") String[] id_tags) {
            PostsEntity postsEntity1 = postsEntityRepo.findById(idpost).orElseThrow();
            postsEntity1.setNamePost(namePost);
            postsEntity1.setCategory(category);
            postsEntity1.setLinkVideo(linkVideo);

            if(id_tags != null && id_tags.length > 0) {
                List<TopicEntity> topicEntities = new ArrayList<>();
                for (String id : id_tags){
                    TopicEntity topic = topicRepo.findById(Long.parseLong(id, 10)).orElseThrow();
                    topicEntities.add(topic);
                }
                postsEntity1.setTags(topicEntities);
            } else {
                postsEntity1.setTags(new ArrayList<TopicEntity>());
            }

            if(postsEntity1.getCategory() != category){
                postsEntity1.setTags(new ArrayList<TopicEntity>());
            }
            //postsEntity1.setCategory(category);
            postsImp.savePost(postsEntity1);
           /* postsImp.savePost(postsEntity);*/
            return "redirect:/main/edit-post/"+idpost;
    }

    @PostMapping("/main/remove-post/{idpost}")
    public String postRemovepost(@PathVariable("idpost") Long idpost, Model model) {
        PostsEntity postsEntity1 = postsEntityRepo.findById(idpost).orElseThrow();
        postsEntityRepo.delete(postsEntity1);
        return "redirect:/main";
    }

    @GetMapping("/profile/{idclient}")
    public String getProfilePage(@PathVariable("idclient") Long idclient, Model model)
    {
        if (idclient == 0)
            return "redirect:/auth/login";
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        return "profile";
    }

    @PostMapping("/profile/{idclient}")
    public String editProfilePage(@PathVariable("idclient") Long idclient, Model model)
    {
        if (idclient == 0)
            return "redirect:/auth/login";
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        model.addAttribute("idclient", idclient);
        return "redirect:edit-profile/{idclient}";
    }

    @GetMapping("/profile/edit-profile/{idclient}")
    public String getEditPage(Model model, @PathVariable("idclient") Long idclient)
    {
        model.addAttribute("clientloginEntity", securityClientLoginImp.findById(idclient));
        model.addAttribute("idclient", idclient);
        if (idclient == 0)
            return "redirect:/auth/login";
        return "edit-profile";
    }

    @PostMapping("/profile/edit-profile/{idclient}")
    public String saveChangesProfile(@ModelAttribute("userForm") @Valid ClientloginEntity userForm, Model model, @PathVariable("idclient") Long idclient)
    {
        if (idclient == 0)
            return "redirect:/auth/login";
        assert userForm != null;
        ClientloginEntity oldUser = securityClientLoginImp.findById(idclient);
        userForm.setLogin(oldUser.getLogin());
        userForm.setPassword(oldUser.getPassword());
        userForm.setIdclient(idclient);
        securityClientLoginImp.updateProfile(userForm);
        model.addAttribute("idclient", idclient);
        model.addAttribute("clientloginEntity", userForm);
        return "profile";
    }

    @GetMapping("../img/{id}")
    private String getImageByID(@PathVariable String id)
    {
        return "src/main/resources/static/img" + id;
    }

    @PostMapping("/auth/register")
    public String save (@ModelAttribute("userForm") @Valid ClientloginEntity userForm, BindingResult bindingResult, Model model){
        if(bindingResult.hasErrors())
        {
            return "register";
        }
        if (!securityClientLoginImp.saveUser(userForm))
        {
            model.addAttribute("usernameError", "Пользователь с таким именем уже существует");
            return "register";
        }
    return "redirect:/auth/login";
    }
}
