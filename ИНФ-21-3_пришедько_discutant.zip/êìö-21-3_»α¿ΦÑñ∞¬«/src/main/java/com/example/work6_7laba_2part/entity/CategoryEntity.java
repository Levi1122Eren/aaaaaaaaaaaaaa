package com.example.work6_7laba_2part.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "category")
public class CategoryEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_category", nullable = false)
    private Integer id_category;

    @Basic
    @Size(max = 255)
    @Column(name = "name")
    private String name = null;

    @Basic
    @Size(max = 255)
    @Column(name = "icon")
    private String icon = null;

    @ManyToMany(fetch = FetchType.EAGER,
            cascade = {
                    CascadeType.PERSIST

            })
    @JoinTable(name = "category_topic",
            joinColumns = { @JoinColumn(name = "id_category") },
            inverseJoinColumns = { @JoinColumn(name = "id_topic") })
    private Set<TopicEntity> tags = new HashSet<>();

    @OneToMany(mappedBy = "categoryEntity")
    private List<PostsEntity> posts;

    @Override
    public String toString() {
        return "CategoryEntity{" +
                "id=" + id_category +
                ", name='" + name + '\'' +
                ", icon='" + icon + '\'' +
                '}';
    }

}
